<?php

function add_application($learner_id, $admin_id, $bus_no) {
    global $db;
    $query = 'INSERT INTO application 
            (LearnerId, AdminId, BusNo)
        VALUES (:learnerid, :adminid, :busno)';
    try {
        $statement = $db->prepare($query);
        $statement->bindValue(':learnerid', $learner_id);
        $statement->bindValue(':adminid', $admin_id);
        $statement->bindValue(':busno', $bus_no);
//    $statement->bindValue(':appstatus', $app_status);
        $success = $statement->execute();
        $row_count = $statement->rowCount();
//    $app_id = $db->lastInsertId();
        $statement->closeCursor();

        //Get last app id generated
        $app_id = $db->lastInsertId();
        return $app_id;
    } catch (PDOException $e) {
        $error_message = $e->getMessage();
        display_db_error($error_message);
    }
//    return $app_id;

    //Display a message to the user
    If ($success) {
        echo "<p>$row_count row(s) was inserted with this ID: $app_id</p>";
    } else {
        echo "<p>No rows were insterted.</p>";
    }
}
