<?php

function get_all_learners() {
    global $db;
    $query = 'SELECT * FROM learner ORDER BY LearnId';
    $statement = $db->prepare($query);
    $statement->execute();
    $learners = $statement->fetchAll();
    $statement->closeCursor();
    return $learners;
}

function add_learner($first_name, $last_name, $contact, $grade, $parent_id) {
    global $db;
    $query = '
        INSERT INTO learner (FirstName, LastName, Contact, Grade, ParentId)
        VALUES (:firstname, :lastname, :contact, :grade, :parentid)';
    $statement = $db->prepare($query);    
    $statement->bindValue(':firstname', $first_name);
    $statement->bindValue(':lastname', $last_name);
    $statement->bindValue(':contact', $contact);
    $statement->bindValue(':grade', $grade);
    $statement->bindValue(':parentid', $parent_id);
    $statement->execute();
    $learner_id = $db->lastInsertId();
    $statement->closeCursor();
    return $learner_id;
}

function update_learner($learner_id, $first_name, $last_name, $contact, $grade,) {
    global $db;
    $query = 'UPDATE learner
        SET FirstName = :first_name,
            LastName = :last_name,
            Contact = :contact,
            Grade = :grade
            WHERE LearnerId = :learnerid';
    
    $statement = $db->prepare($query);
    $statement->bindValue(':learnerid', $learner_id, PDO::PARAM_INT);
    $statement->bindValue(':first_name', $first_name, PDO::PARAM_STR);
    $statement->bindValue(':last_name', $last_name, PDO::PARAM_STR);
    $statement->bindValue(':contact', $contact, PDO::PARAM_STR);
    $statement->bindValue(':grade', $grade, PDO::PARAM_INT);
    $statement->execute();
    $statement->closeCursor();
}
