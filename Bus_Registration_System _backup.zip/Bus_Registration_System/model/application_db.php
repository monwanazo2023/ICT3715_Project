<?php

function get_all_application()
{
    global $db;
    $query = 'SELECT * FROM application ORDER BY AppId';
    $statement = $db->prepare($query);
    $statement->execute();
    $applications = $statement->fetchAll();
    $statement->closeCursor();
    return $applications;
}

function add_application($learner_id, $admin_id, $bus_no, $pick_id)
{
    global $db;

    $query = 'INSERT INTO application 
            (LearnerId,AdminId, BusNo, PickId)
            VALUES 
            (:learnerid, :adminid, :busno, :pickid)';
    try {
        $statement = $db->prepare($query);
        $statement->bindValue(':learnerid', $learner_id);
        $statement->bindValue(':adminid', $admin_id);
        $statement->bindValue(':busno', $bus_no);
        $statement->bindValue(':pickid', $pick_id);
        $success = $statement->execute();
        $row_count = $statement->rowCount();
        $statement->closeCursor();

        //Get last app id generated
        $app_id = $db->lastInsertId();
        return $app_id;
    } catch (PDOException $e) {
        $error_message = $e->getMessage();
        return ($error_message);
    }

    //Display a message to the user
    if ($success) {
        echo "<p>$row_count row(s) was inserted with this ID: $app_id</p>";
    } else {
        echo "<p>No rows were insterted.</p>";
    }
}

function update_learner($learner_id, $bus_no, $pick_id)
{
    global $db;
    $query = '
        UPDATE learner
        SET BusNo = :busno,
        PickId = :pickid
        WHERE LearnerId = :learnerid';

    $statement = $db->prepare($query);
    $statement->bindValue(':learnerid', $learner_id, PDO::PARAM_INT);
    $statement->bindValue(':busno', $bus_no, PDO::PARAM_INT);
    $statement->bindValue(':pickid', $pick_id, PDO::PARAM_INT);
    $statement->execute();
    $statement->closeCursor();
}

function update_application($app_id, $learner_id, $admin_id, $bus_no, $pick_id)
{
    global $db;
    $query = '
        UPDATE application
        SET LearnerId = :learnerid,
            AdminId = :adminid,
            BusNo = :busno
            PickId = :pickid
        WHERE AppId = :appid';

    $statement = $db->prepare($query);
    $statement->bindValue(':appid', $app_id);
    $statement->bindValue(':learnerid', $learner_id);
    $statement->bindValue(':adminid', $admin_id);
    $statement->bindValue(':busno', $bus_no);
    $statement->bindValue(':pickid', $pick_id);
    $statement->execute();
    $statement->closeCursor();
}

function get_busCount()
{
    global $db;
    $query = 'SELECT COUNT(*) FROM learner WHERE BusNo = 1';
    $statement = $db->prepare($query);
    $statement->execute();
    $bus1_count = $statement->fetchColumn();
    $statement->closeCursor();
    return $bus1_count;
}

function add_waitList($learner_id)
{
    $to_date = date("Y-m-d");
    global $db;
    $query = 'INSERT INTO waitlist 
            (LearnerId, WaitDate)
            VALUES 
            (:learnerid, :to_date)';
    try {
        $statement = $db->prepare($query);
        $statement->bindValue(':learnerid', $learner_id);
        $statement->bindValue(':to_date', $to_date);
        $statement->execute();
        $statement->closeCursor();

        //Get last waitlist id generated
        $wait_id = $db->lastInsertId();
        return $wait_id;
    } catch (PDOException $e) {
        $error_message = $e->getMessage();
        return ($error_message);
    }
}
