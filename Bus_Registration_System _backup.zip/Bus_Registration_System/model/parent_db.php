<?php

function is_valid_parent_login($email, $password) {
    global $db;
    $password = sha1($email . $password);
    $query = 'SELECT * FROM parent
              WHERE emailAddress = :email AND PassCode = :password';
    $statement = $db->prepare($query);
    $statement->bindValue(':email', $email);
    $statement->bindValue(':password', $password);
    $statement->execute();
    $valid = ($statement->rowCount() == 1);
    $statement->closeCursor();
    return $valid;
}

function is_valid_parent_email($email) {
    global $db;
    $query = '
        SELECT * FROM parent
        WHERE emailAddress = :email';
    $statement = $db->prepare($query);
    $statement->bindValue(':email', $email);
    $statement->execute();
    $valid = ($statement->rowCount() == 1);
    $statement->closeCursor();
    return $valid;
}

function get_parent_by_email($email) {
    global $db;
    $query = 'SELECT * FROM parent WHERE emailAddress = :email';
    $statement = $db->prepare($query);
    $statement->bindValue(':email', $email);
    $statement->execute();
    $parent = $statement->fetch();
    $statement->closeCursor();
    return $parent;
}

function add_parent($first_name, $last_name, $contact, $email, $password) {
    global $db;
    $hashedPwd = password_hash($password, PASSWORD_DEFAULT);
    $query = 'INSERT INTO parent 
                (FirstName, LastName, Contact, emailAddress, PassCode)
              VALUES 
                (:first_name, :last_name, :contact, :email, :password)';
    try {
        $statement = $db->prepare($query);
        $statement->bindValue(':first_name', $first_name);
        $statement->bindValue(':last_name', $last_name);
        $statement->bindValue(':contact', $contact);
        $statement->bindValue(':email', $email);
        $statement->bindValue(':password', $hashedPwd);
        $success = $statement->execute();
        $row_count = $statement->rowCount();
        $statement->closeCursor();

//Get last parent id generated
        $parent_id = $db->lastInsertId();
        return $parent_id;
    } catch (PDOException $e) {
        $error_message = $e->getMessage();
        display_db_error($error_message);
    }

    //Display a message to the user
    If ($success) {
        echo "<p>$row_count row(s) was inserted with this ID: $parent_id</p>";
    } else {
        echo "<p>No rows were insterted.</p>";
    }
}


