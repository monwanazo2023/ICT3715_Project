<?php

function get_all_waitlist() {
    global $db;
    $query = 'SELECT * FROM waitlist ORDER BY WaitDate, LearnId';
    $statement = $db->prepare($query);
    $statement->execute();
    $waitlist = $statement->fetchAll();
    $statement->closeCursor();
    return $waitlist;
}

function add_waitlist($wait_id, $app_id, $learn_id, $first_name, $last_name, $wait_date) {
    global $db;
    $query = '
        INSERT INTO waitlist (WaitId, AppId, LearnId, FirstName, LastName, WaitDate)
        VALUES (:waitid, :appid, :learnid, :firstname, :lastname, :waitdate)';
    $statement = $db->prepare($query);
    $statement->bindValue(':waitid', $wait_id);
    $statement->bindValue(':appid', $app_id);
    $statement->bindValue(':learnid', $learn_id);
    $statement->bindValue(':firstname', $first_name);
    $statement->bindValue(':lastname', $last_name);
    $statement->bindValue(':waitdate', $wait_date);
    $statement->execute();
    $wait_id = $db->lastInsertId();
    $statement->closeCursor();
    return $wait_id;
}

function update_waitlist($wait_id, $app_id, $learn_id, $first_name, $last_name, $wait_date) {
    global $db;
    $query = '
        UPDATE waitlist
        SET FirstName = :firstname,
            LastName = :lastname,
            WaitDate = :waitdate
        WHERE WaitId = :waitid';
    $statement = $db->prepare($query);
    $statement->bindValue(':firstname', $first_name);
    $statement->bindValue(':lastname', $last_name);
    $statement->bindValue(':waitdate', $wait_date);
    $statement->bindValue(':waitid', $wait_id);
    $statement->execute();
    $statement->closeCursor();
}

function delete_waitlist($wait_id) {
    global $db;
    $query = 'DELETE FROM waitlist WHERE WaitId = :waitid';
    $statement = $db->prepare($query);
    $statement->bindValue(':waitid', $wait_id);
    $statement->execute();
    $statement->closeCursor();
}
