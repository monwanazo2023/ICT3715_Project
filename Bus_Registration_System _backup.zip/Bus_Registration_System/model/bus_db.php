<?php

function get_all_bus() {
    global $db;
    $query = 'SELECT * FROM bus ORDER BY BusNo';
    $statement = $db->prepare($query);
    $statement->execute();
    $buses = $statement->fetchAll();
    $statement->closeCursor();
    return $buses;
}