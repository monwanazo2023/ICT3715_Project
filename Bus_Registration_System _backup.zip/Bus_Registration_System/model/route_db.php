<?php

function get_all_route() {
    global $db;
    $query = 'SELECT * FROM route ORDER BY PickId';
    $statement = $db->prepare($query);
    $statement->execute();
    $routes = $statement->fetchAll();
    $statement->closeCursor();
    return $routes;
}