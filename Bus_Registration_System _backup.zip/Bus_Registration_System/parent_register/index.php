<?php

require_once '../model/parent_db.php';
require_once '../model/brt_database.php';

require_once '../model/fields.php';
require_once '../model/validate.php';

$action = filter_input(INPUT_POST, 'action');
if ($action === NULL) {
    $action = 'reset';
} else {
    $action = strtolower($action);
}

// Set up all possible fields to validate
$validate = new Validate();
$fields = $validate->getFields();

// for the Registration page and other pages
$fields->addField('first_name');
$fields->addField('last_name');
$fields->addField('contact');

switch ($action) {
    case 'reset':
        $first_name = '';
        $last_name = '';
        $contact = '';

        include 'parent_register_form.php';
        break;
    case 'register':
// Copy form values to local variables
        $first_name = filter_input(INPUT_POST, 'first_name');
        $last_name = filter_input(INPUT_POST, 'last_name');
        $contact = filter_input(INPUT_POST, 'contact');
        $email = filter_input(INPUT_POST, 'email');
        $password = filter_input(INPUT_POST, 'password');

// Validate form data
        $validate->text('first_name', $first_name);
        $validate->text('last_name', $last_name);
        $validate->phone('contact', $contact);

//         Load appropriate view based on hasErrors
        if ($fields->hasErrors()) {
            include 'parent_register_form.php';
        } else {
            include '../parent/parent_page.php';
        }

        //add parent info to the database
        $parent_id = add_parent($first_name, $last_name, $contact, $email, $password);
        break;
}
