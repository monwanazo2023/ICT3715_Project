<?php
include '../view/header.php';
?> 
<br><br> 
<div class="container">
    <div class="row">
        <div class="col xs-12">
            <form action="." method="post" id="form-register">
                <input type="hidden" name="action" value="register">
                <div>
                    <h3 class="h3 mb-3 font-weight-normal">Parent Sign Up Form</h3><br>
                    <label for="firstname">First Name</label>
                    <input type="text" name="first_name" class="form-control" placeholder="First Name" 
                           value="" required><br>
                    <label for="lastname">Last Name</label>
                    <input type="text" name="last_name" class="form-control" placeholder="Last Name" 
                           value="" required><br>
                    <label for="contact">Contact</label>
                    <input type="phone" name="contact" class="form-control" placeholder="Contact" 
                           value="" required><br>
                    <label for="email">Email address</label>
                    <input type="email" name="email" class="form-control" placeholder="Email address" 
                           value="" size="30" required><br>
                    <label for="password">Password</label>
                    <input type="password" name="password" class="form-control" placeholder="Password" 
                           value="" required><br>
                </div>
                <div>
                    <button class="btn btn-lg btn-primary btn-block" type="submit">Submit</button>
                </div>
            </form>
        </div>
    </div>
</div>
<br><br>
</body>
<?php
include '../view/footer.php';

