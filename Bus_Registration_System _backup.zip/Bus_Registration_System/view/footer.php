<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<!--<script src="../JavaScript/learner.js"/>-->

<script>
    function fetchLearner(val) {
        $.ajax({
            type: "POST",
            url: "../bus/getLearner.php",
            data: 'learnerid=' + val,
            success: function (data) {
                $("#learnerDetails").html(data);
            }
        });
    }
    function selectLearner(val) {
        $("#learnerid").val(val);
        $("#suggestion-box").hide();
    }


    function fetchBus(val) {
        $.ajax({
            type: "POST",
            url: "../bus/getBusInfo.php",
            data: 'busno=' + val,
            success: function (data) {
                $("#busDetails").html(data);
            }
        });
    }
    function selectBus(val) {
        $("#busno").val(val);
        $("#suggestion-box").hide();
    }

    function fetchPick(val) {
        $.ajax({
            type: "POST",
            url: "../bus/getPickInfo.php",
            data: 'pickid=' + val,
            success: function (data) {
                $("#pickDetails").html(data);
            }
        });
    }
    function selectPick(val) {
        $("#pickid").val(val);
        $("#suggestion-box").hide();
    }
    function fetchAdmin(val) {
        $.ajax({
            type: "POST",
            url: "../bus/getAdminInfo.php",
            data: 'adminid=' + val,
            success: function (data) {
                $("#adminDetails").html(data);
            }
        });
    }
    function selectAdmin(val) {
        $("#adminid").val(val);
        $("#suggestion-box").hide();
    }
    function fetchWaitInfo(val) {
        $.ajax({
            type: "POST",
            url: "../administrator/getWaitListInfo.php",
            data: 'learnerid=' + val,
            success: function (data) {
                console.log(data);
                $("#waitDetails").html(data);
            }
        });
    }
    function selectWait(val) {
        $("#learnerid").val(val);
        $("#suggestion-box").hide();
    }
</script>

<div class="container text-center">
    <footer class="panel-footer"><p class="text-body-secondary">© 2023</p></footer>
</div>
</html> 