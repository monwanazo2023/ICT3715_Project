<!DOCTYPE html>
<html>
    <head>
        <title>Impumelelo High School</title>

        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
        <link rel="stylesheet" href="bower_components/jquery/external/qunit/qunit.css" type="text/css"/>
        <link href="source/customStyles.css" rel="stylesheet" type="text/css"/>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <body class="">
        <div class="container">
            <nav class="navbar navbar-inverse">
                <div class="container-fluid">
                    <div class="navbar-header">
                        <a class="navbar-brand" href="#">IHS Bus Registration System</a>
                    </div>
                    <div>
                        <ul class="nav navbar-nav">
                            <li><a href="brt_landing.php"">Home</a></li>     
                            <li><a href="#"><span class="glyphicon glyphicon-globe"></span> About us</a></li>
                            <li><a href="#"><span class="glyphicon glyphicon-envelope"></span> Contact us</a></li>                  
                        </ul>
                    </div>
                </div>
            </nav>
        </div>
        <div class="container">
            <h3 class="text-center">Welcome to the IHS Bus Registration System!</h3>  
        </div>