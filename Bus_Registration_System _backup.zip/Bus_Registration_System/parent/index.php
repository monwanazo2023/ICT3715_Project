<?php
//require_once '..view/brt_landing.php';
require_once '../model/brt_database.php';
require_once '../model/parent_db.php';

require_once '../model/fields.php';
require_once '../model/validate.php';

$action = filter_input(INPUT_POST, 'action');
if ($action === NULL) {
    $action = 'reset';
} else {
    $action = strtolower($action);
}

// Set up all possible fields to validate
$validate = new Validate();
$fields = $validate->getFields();

// for login page
$fields->addField('email', 'Must be valid email.');
$fields->addField('password');

switch ($action) {
    case 'reset':
        $email = '';
        $password = '';
        include 'parent_login.php';
        break;
        case 'login':
            $email = filter_input(INPUT_POST, 'email');
            $password = filter_input(INPUT_POST, 'password');

            // Validate user data
            $validate->email('email', $email);
            $validate->text('password', $password, true, 6, 30);

            // If validation errors, redisplay Login page and exit controller
            if ($fields->hasErrors()) {
                include 'parent_login.php';
                break;
            }

//        // Check email and password in database
//        if (is_valid_admin_login($email, $password)) {
//            session_start();
//            $_SESSION['AdminId'] = get_admin_by_email($email);
//            include 'admin_page.php';
//        } else {
//            $password_message = 'Login failed. Invalid email or password.';
//            include 'admin_login.php';
//            break;
//        }

        //Load appropriate view based on hasErrors
        if ($fields->hasErrors()) {
            include 'parent_login.php';
        } else {
            include 'parent_page.php';
        }


}
