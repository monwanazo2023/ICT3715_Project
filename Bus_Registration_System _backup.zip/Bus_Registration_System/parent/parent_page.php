<?php
include '../view/header.php';
?>

<br><br>
<div class="container">
    <div class="container-fluid">
        <div class="row">
            <h4 class="text-center">What do you would you like to do today?</h4>
        </div>
        <br>
        <div class="row">
            <div class="col-lg-3 col-lg-offset-2 ">
                <p><a href="../learner/learner_register_form.php" class="btn btn-primary btn-lg"> Register New Learner</a></p>
            </div>     
            <div class="col-lg-3">
                <p><a href="../learner/parent_learner_update.php" class="btn btn-primary btn-lg"> Maintain Learner Info</a></p> 
            </div>
            <div class="col-lg-3"> 
                <p><a href="../bus/application_form.php" class="btn btn-primary btn-lg"> Apply for the Bus</a></p>
            </div>
        </div>
        <br><br>
    </div>
</div>
</div>
<br><br>
</body>
<?php
include '../view/footer.php';

