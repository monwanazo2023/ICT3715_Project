<?php

error_reporting(E_ALL ^ E_DEPRECATED);
require_once('../model/parent_message');

$action = filter_input(INPUT_POST, 'action');
if ($action === NULL) {
    $action = 'reset';
} else {
    $action = strtolower($action);
}

switch ($action) {
    case 'reset':
        // Reset values for variables
        $first_name = '';
        $last_name = '';
        $phone = '';
        $email = '';

        // Load view
        include 'application_form.php';
        break;
    case 'register':
        // Copy form values to local variables
        $first_name = trim(filter_input(INPUT_POST, 'first_name'));
        $last_name = trim(filter_input(INPUT_POST, 'last_name'));
        $phone = trim(filter_input(INPUT_POST, 'phone'));
        $email = trim(filter_input(INPUT_POST, 'email'));

        // Set up email variables
        $to_address = $email;
        $to_name = $first_name . ' ' . $last_name;
        $from_address = 'monwa.nazo@gmail.com';
        $from_name = 'Monwabisi Nazo';
        $subject = 'Application submitted succesful!';
        $body = '<p>Thanks for apply for space on the bus for your learner.</p>' .
                '<p>Sincerely,</p>' .
                '<p>Impumelelo High School</p>';
        $is_body_html = true;

        // Send email
        send_email($to_address, $to_name,
                $from_address, $from_name,
                $subject, $body, $is_body_html);

        break;
}