<?php

error_reporting(E_ALL ^ E_DEPRECATED);

require_once '../model/brt_database.php';
require_once '../model/fields.php';
require_once '../model/validate.php';
require_once '../model/learner_db.php';
require_once '../model/email_message.php';

$action = filter_input(INPUT_POST, 'action');
if ($action === NULL) {
    $action = 'reset';
} else {
    $action = strtolower($action);
}

// Set up all possible fields to validate
$validate = new Validate();
$fields = $validate->getFields();

// for the Registration page and other pages
$fields->addField('first_name');
$fields->addField('last_name');
$fields->addField('contact');

switch ($action) {
    case 'reset_register':
        //Reset values for variables
        $learner_id = '';
        $first_name = '';
        $last_name = '';
        $contact = '';
        $grade = '';
        $parent_id = '';

        //Load View    
        include 'learner_register_form.php';
        break;
    case 'reset_update':
        //Reset values for variables
        $learner_id = '';
        $first_name = '';
        $last_name = '';
        $contact = '';
        $grade = '';
        $parent_id = '';

        //Load View    
        include 'learner_update.php';
        break;
    case 'register':
        // Copy form values to local variables
        $first_name = filter_input(INPUT_POST, 'first_name');
        $last_name = filter_input(INPUT_POST, 'last_name');
        $contact = filter_input(INPUT_POST, 'contact');
        $grade = filter_input(INPUT_POST, 'grade');
        $parent_id = filter_input(INPUT_POST, 'parent_id');

        // Validate form data
        $validate->text('first_name', $first_name);
        $validate->text('last_name', $last_name);
        $validate->phone('contact', $contact);

        //add learner info to the database
        $learner_id = add_learner($first_name, $last_name, $contact, $grade, $parent_id);

        // Set up email variables
        $to_address = '43205364@mylife.unisa.ac.za';
        $to_name = 'Monwabisi Nazo';
        $from_address = 'monwa.nazo@gmail.com';
        $from_name = 'Monwabisi Nazo';
        $subject = 'Learner Registration Complete';
        $body = '<p>Thank you for registering your learner for the bus transport.</p>' .
            '<p>Next step is to apply for space before its too late!.</p>' .
            '<p>Regards,</p>' .
            '<p>Impumelelo High School</p>';
        $is_body_html = true;

        // Send email
        try {
            send_email(
                $to_address,
                $to_name,
                $from_address,
                $from_name,
                $subject,
                $body,
                $is_body_html
            );
            echo 'Registration completed successfully!';
            include '../parent/parent_page.php';
        } catch (Exception $ex) {
            $error = $ex->getMessage();
            include 'learner_register_form.php';
        }
        break;
    case 'update':
        // Copy form values to local variables
        $learner_id = filter_input(INPUT_POST, 'learnerid');
        $first_name = filter_input(INPUT_POST, 'first_name');
        $last_name = filter_input(INPUT_POST, 'last_name');
        $contact = filter_input(INPUT_POST, 'contact');
        $grade = filter_input(INPUT_POST, 'grade');

        //update learner information
        update_learner($learner_id, $first_name, $last_name, $contact, $grade);

        //Load appropriate view based on hasErrors
        if ($fields->hasErrors()) {
            echo 'Could not update your Information at this time.';
            include 'learner_update.php';
        } else {
            include '../parent/parent_page.php';
            echo 'Information updated successfully!';
        }
        break;
}
