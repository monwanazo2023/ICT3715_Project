<?php
include '../view/header.php';
require_once '../model/brt_database.php';

//Connect to DB
$con = mysqli_connect("localhost", "root", "", "bus_registration_system");

//Get parents id's
$query1 = mysqli_query($con, "select * from parent");

//Get learner id's
$query2 = mysqli_query($con, "select * from learner");
?>

<br>
<div class="container">
    <div class="form">
        <form action="." method="post" id="form-register">
            <input type="hidden" name="action" value="update">
            <h3 class="h3 mb-3 font-weight-normal">Update Learner Information</h3><br>
            <div class="col-lg-12 ">
                <label for="learnerid">LearnerId</label>
                <select name="learnerid" id="learnerid" class="form-control" onChange="fetchLearner(this.value);">
                    <option value="">Select Learner Id</option>
                    <?php
                    while ($r = mysqli_fetch_assoc($query2)) {
                        $k = $r['LearnerId'];
                        echo '<option value="' . $k . '">' . $k . '</option>';
                    }
                    ?>
                </select>
                <br>
                <div id="learnerDetails">
                    <label for="firstname">Learner First Name</label>
                    <input type="text" name="learnerfname" id="learnerfname" class="form-control"
                        placeholder="First Name" value="" required>
                    <br>
                    <label for="lastname">Learner Last Name</label>
                    <input type="text" name="learnerlname" id="learnerlname" class="form-control"
                        placeholder="Last Name" value="" required>
                    <br>
                    <label for="contact">Learner Contact</label>
                    <input type="text" name="learnercontact" id="learnercontact" class="form-control"
                        placeholder="Contact" value="" required><br>
                    <label for="grade">Grade</label>
                    <input type="text" name="grade" id="grade" class="form-control" placeholder="Grade  " value=""
                        required><br>
                    <label for="parent">ParentId</label>
                    <input type="text" name="parentid" id="parentid" class="form-control" placeholder="Parent Id"
                        value="" required><br>
                </div>
            </div>
            <div>
                <button class="btn btn-lg btn-primary btn-block" type="submit" name="action"
                    value="update">Update</button><br>
                <button class="btn btn-lg btn-primary btn-block" type="submit" name="action"
                    value="reset_update">Reset</button>
            </div>
        </form>
    </div>
</div>
</br></br>
</body>
<?php
include '../view/footer.php';

