function fetchLearner(val) {
    $.ajax({
        type: "POST",
        url: "../bus/getLearner.php",
        data: 'learnerid=' + val,
        success: function (data) {
            $("#learnerDetails").html(data);
        }
    });
}
function selectLearner(val) {
    $("#learnerid").val(val);
    $("#suggestion-box").hide();
}

