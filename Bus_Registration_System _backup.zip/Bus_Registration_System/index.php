<?php

require_once('view/brt_landing.php');
require_once('model/brt_database.php');



