<?php
include '../view/header.php';
require_once '../model/brt_database.php';

//Connection to DB
$con = mysqli_connect("localhost", "root", "", "bus_registration_system");

//Get parent id's
$s = mysqli_query($con, "select ParentId from parent");
?>

<br>
<div class="container">
    <div class="form">
        <div class="col xs-12">
            <form action="." method="post" id="form-register">
                <input type="hidden" name="action" value="register">
                <div>
                    <h3 class="h3 mb-3 font-weight-normal">Learner Registration Form</h3><br>
                    <label for="firstname">First Name</label>
                    <input type="text" name="first_name" id="first_name" class="form-control" placeholder="First Name" 
                           value="" required><br>
                    <label for="lastname">Last Name</label>
                    <input type="text" name="last_name" id="last_name" class="form-control" placeholder="Last Name" 
                           value="" required><br>
                    <label for="contact">Contact</label>
                    <input type="text" name="contact" id="contact" class="form-control" placeholder="Contact" 
                           value="" required><br>
                    <label for="grade">Grade</label>
                    <select name="grade" id="grade" class="form-control">
                        <option value="8">8</option>
                        <option value="9">9</option>
                        <option value="10">10</option>
                        <option value="11">11</option>
                        <option value="12">12</option>
                    </select><br>
                    <label for="parent">ParentId</label>
                    <select name="parent_id" id="parent_id" class="form-control">
                        <?php
                        while ($r = mysqli_fetch_assoc($s)) {
                            ?>
                            <option><?php echo $r['ParentId']; ?></option>
                            <?php
                        }
                        ?>
                    </select><br>
                </div>
                <div>
                    <button class="btn btn-lg btn-primary btn-block" type="submit" name="action" value="register">Submit</button><br>
                    <button class="btn btn-lg btn-primary btn-block" type="submit" name="action" value="reset_register">Reset</button>
                </div>
            </form>
        </div>
    </div>
</div>
</br></br>
</body>
<?php
include '../view/footer.php';

