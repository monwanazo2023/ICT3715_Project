<?php
include '../view/header.php';
?>

<br><br>
<div class="container">
    <div class="container-fluid">
        <div class="row">
            <h4 class="text-center">Administration Tasks</h4>
        </div>
        </br>
        <div class="row">
            <div class="col-lg-3">
                <p><a href="admin_learner_register_form.php" class="btn btn-primary btn-lg"> Register New Learner</a></p>
            </div>     
            <div class="col-lg-3">
                <p><a href="admin_learner_update.php" class="btn btn-primary btn-lg"> Maintain Learner Info</a></p> 
            </div>
            <div class="col-lg-3"> 
                <p><a href="parent_login.html" class="btn btn-primary btn-lg"> Update Applications</a></p>
            </div>
            <div class="col-lg-3"> 
                <p><a href="move_waiting.php" class="btn btn-primary btn-lg"> Move from Waiting List</a></p>
            </div>
        </div>
        </br></br>
        <div class="row">
            <h4 class="text-center">Reporting</h4>
        </div>
        </br>
        <div class="row">
            <div class="col-lg-3">
                <p><a href="../waitlist_report/index.php" class="btn btn-primary btn-lg"> Waiting List Report</a></p>
            </div>
            <div class="col-lg-3">                    
                <p><a href="../dailybus_report/index.php" class="btn btn-primary btn-lg"> Daily Ride Report</a></p>
            </div>
            <div class="col-lg-3">
                <p><a href="admin_login.html" class="btn btn-primary btn-lg"> Weekly Ride Report</a></p>                         
            </div>   
            <div class="col-lg-3">
                <p><a href="../applications_report/index.php" class="btn btn-primary btn-lg"> Past Applications Report</a></p>                         
            </div>   
        </div>                
    </div>
</div>
</div>
<br><br>
</body>
<?php
include '../view/footer.php';

