<?php
include '../view/header.php';
?>

<br><br> 
<div class="container">
    <div class="row">
        <div class="col xs-12">
            <form action="." method="post" id="form-signin">
                <input type="hidden" name="action" value="login">
                <div>
                    <h3 class="h3 mb-3 font-weight-normal">Administrator sign in</h3><br>
                    <label for="email">Email address</label>
                    <input type="email" name="email" class="form-control" placeholder="Email address" required autofocus><br>
                    <label for="password">Password</label>
                    <input type="password" name="password" class="form-control" placeholder="Password" required>
                </div>
                <div class="checkbox mb-3">
                    <label>
                        <input type="checkbox" value="remember-me">Remember me
                    </label>
                </div>
                <div>
                    <button class="btn btn-lg btn-primary btn-block" type="submit">Sign in</button>
                </div>
                <br>
            </form>
        </div>
    </div>
</div>
<br></br>
</body>
<?php
include '../view/footer.php';

