<?php

require_once '../model/brt_database.php';

//Connection to DB
$con = mysqli_connect("localhost", "root", "", "bus_registration_system");

$k = $_POST["learnerid"];
// $query = "select * from learner where LearnerId = {$k}";
$query = "select waitlist.WaitId, waitlist.LearnerId, learner.FirstName, learner.LastName, learner.Contact, learner.Grade, learner.ParentId,
application.BusNo, application.PickId
from waitlist
inner join learner on learner.learnerid = waitlist.learnerid
inner join application on application.learnerid = waitlist.learnerid where waitlist.LearnerId = {$k}";

$result = mysqli_query($con, $query);
$rows = mysqli_fetch_array($result);
if ($rows == true) {
        print '<label for="firstname">Learner First Name</label>
            <input type="text" name="first_name" id="learnerfname" class="form-control" placeholder="First Name" 
                       value="' . $rows["FirstName"] . '" required>'
                . '<br>
                <label for="lastname">Learner Last Name</label>
                <input type="text" name="last_name" id="learnerlname" class="form-control" placeholder="Last Name" 
                       value="' . $rows["LastName"] . '" required>'
                . '<br>
                <label for="contact">Learner Contact</label>
                <input type="text" name="contact" id="learnercontact" class="form-control" placeholder="Contact" 
                       value="' . $rows["Contact"] . '" required>'
                . '<br>
                <label for="grade">Grade</label>
                <input type="text" name="grade" id="grade" class="form-control" placeholder="Grade" 
                       value="' . $rows["Grade"] . '" required>'
                . '<br>
                  <label for="parent">Parent Id</label>
                <input type="text" name="parent_id" id="parentid" class="form-control" placeholder="Parent Id" 
                       value="' . $rows["ParentId"] . '" required>'
                . '<br>
                 <label for="busnumber">Bus Number</label>
                <input type="text" name="busno" id="busno" class="form-control" placeholder="Bus Number" 
                       value="' . $rows["BusNo"] . '" required>'
                . '<br>
                  <label for="pickid">Pick Id</label>
                <input type="text" name="pickid" id="pickid" class="form-control" placeholder="Pick Id" 
                       value="' . $rows["PickId"] . '" required>'
                . '<br>'
                . '';
}
