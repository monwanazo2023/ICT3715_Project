<?php 

include_once '../view/header.php';

require_once "learnersInBus.php";
$learnerslist = new LearnersInBus;
$learnerslist->run()->render();

include_once '../view/footer.php';