<?php

require_once "../koolreport/core/autoload.php";

use \koolreport\processes\Group;
use \koolreport\processes\Sort;
use \koolreport\processes\Limit;

class learnersInBus extends \koolreport\KoolReport {

    use \koolreport\clients\Bootstrap;

    protected function settings() {
        return array(
            "dataSources" => array(
                "learners" => array(
                    'connectionString' => 'mysql:host=localhost;dbname=bus_registration_system',
                    'username' => 'root',
                    'password' => '',
                    'charset' => 'utf8'
                ),
            )
        );
    }

    public function setup() {
        $this->src("learners")
                ->query("SELECT `learner`.`LearnerId`,`learner`.`FirstName`,`learner`.`LastName`,`learner`.`Contact`,
    `learner`.`Grade`,`bus`.`BusNo`,`bus`.`BusRouteNo`,`route`.`PickNo`,`route`.`PickName`,`route`.`PickTime`,`route`.`DropNo`,`route`.`DropName`,`route`.`DropTime`
    FROM `learner` INNER JOIN `bus` ON `bus`.`BusNo` = `learner`.`BusNo`
 INNER JOIN `route` ON `learner`.`PickId` = `route`.`PickId`")
                ->SaveTo($root)
                ->pipe($this->dataStore('learners_in_bus'));

        $root->pipe(new Group(array(
                            "by" => "LearnerId",
  
                        )
        )
        );
}}
