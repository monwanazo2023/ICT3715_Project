<?php 

include_once '../view/header.php';

require_once "busApplications.php";
$applications = new busApplications;
$applications->run()->render();

include_once '../view/footer.php';