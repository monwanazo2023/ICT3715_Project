<?php

require_once "../koolreport/core/autoload.php";

use \koolreport\processes\Group;
use \koolreport\processes\Sort;
use \koolreport\processes\Limit;

class busApplications extends \koolreport\KoolReport {

    use \koolreport\clients\Bootstrap;

    protected function settings() {
        return array(
            "dataSources" => array(
                "applications" => array(
                    'connectionString' => 'mysql:host=localhost;dbname=bus_registration_system',
                    'username' => 'root',
                    'password' => '',
                    'charset' => 'utf8'
                ),
            )
        );
    }

    public function setup() {
        $this->src("applications")
                ->query("SELECT `application`.`AppId`, `application`.`LearnerId`, `application`.`BusNo`, 
                    `learner`.`FirstName`, `learner`.`LastName`, `learner`.`Contact`, `learner`.`Grade`
                    FROM `application`
                    INNER JOIN `learner` ON `learner`.`LearnerId` = `application`.`LearnerId`
                    GROUP BY `learner`.`LearnerId`")
                ->SaveTo($root)
                ->pipe($this->dataStore('bus_applications'));

        $root->pipe(new Group(array(
                            "by" => "LearnerId",
                        )
        )
        );
//                ->pipe(new Limit(array(10)))
//                ->pipe($this->dataStore('learners_by_bus'));
//    }
}}
