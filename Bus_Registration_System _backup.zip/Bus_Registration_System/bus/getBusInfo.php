<?php

require_once '../model/brt_database.php';

//Get bus information

$con = mysqli_connect("localhost", "root", "", "bus_registration_system");
$j = $_POST["busno"];
$query = "select * from bus where BusNo = {$j}";
$result = mysqli_query($con, $query);
$rows = mysqli_fetch_array($result);
if ($rows == true) {
    print ' <label for="bus_route">Bus Route Name</label>
            <input type="text" name="bus_route" id="busroute" class="form-control" placeholder="Bus Route Name" 
                      value="' . $rows["BusRouteNo"] . '" required>'
            .'<br>'
            . '';
}   
