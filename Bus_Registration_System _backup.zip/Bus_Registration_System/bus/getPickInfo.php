<?php

require_once '../model/brt_database.php';

//Get pick id's

$con = mysqli_connect("localhost", "root", "", "bus_registration_system");
$l = $_POST["pickid"];
$query = "select * from route where PickId = {$l}";
$result = mysqli_query($con, $query);
$rows = mysqli_fetch_array($result);
if ($rows == true) {
    print '<label for="pick_number">Pick Number</label>
            <input type="text" name="pick_number" id="picknumber" class="form-control" placeholder="Pick Number" 
                       value="' . $rows["PickNo"] . '" required>'
            . '<br>
                <label for="pick_name">Pick Name</label>
                <input type="text" name="pick_name" id="pickname" class="form-control" placeholder="Pick Name" 
                       value="' . $rows["PickName"] . '" required>'
            . '<br>
                <label for="pick_time">Pick Time</label>
                <input type="text" name="pick_time" id="picktime" class="form-control" placeholder="Pick Time" 
                       value="' . $rows["PickTime"] . '" required>'
            . '<br>
                <label for="drop_number">Drop Number</label>
                <input type="text" name="drop_number" id="dropnumber" class="form-control" placeholder="Drop Number" 
                       value="' . $rows["DropNo"] . '" required>'
            . '<br>
                 <label for="drop_name">Drop Name</label>
                <input type="text" name="drop_name" id="dropname" class="form-control" placeholder="Drop Name" 
                       value="' . $rows["DropName"] . '" required>'
            . '<br>
                 <label for="drop_time">Drop Time</label>
                <input type="text" name="drop_time" id="droptime" class="form-control" placeholder="Drop Time" 
                       value="' . $rows["DropTime"] . '" required>'
            . '<br>'
            . '';
}   
