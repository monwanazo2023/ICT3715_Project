<?php
include '../view/header.php';
?>

<br><br>
<div class="container">
    <div class="container">
        <div class="row">
            <div class="col-lg-4 col-md-8 col-sm-12 col-lg-offset-3">
                <p><a href="../parent/parent_login.php" class="btn btn-primary btn-lg"><span class="glyphicon glyphicon-log-in"></span> I am a parent</a></p>
                </br>
                <img src="../images/parent2.jpg" alt="" class="col-md-4 img-responsive img-circle"/>                        
            </div>
            <div class="col-lg-4 col-md-8 col-sm-12">
                <p><a href="../administrator/admin_login.php" class="btn btn-primary btn-lg"><span class="glyphicon glyphicon-log-in"></span> I am an administrator</a></p>
                </br>
                <img src="../images/admin3.jpg" alt="" class="col-md-4 img-responsive img-circle"/>
            </div>                  
        </div>
    </div>
</div>
</br></br>
</body>
<?php
include '../view/footer.php';




