<?php

error_reporting(E_ALL ^ E_DEPRECATED);
require_once '../model/application_db.php';
require_once '../model/brt_database.php';
require_once '../model/fields.php';
require_once '../model/validate.php';
require_once '../model/email_message.php';

$action = filter_input(INPUT_POST, 'action');
if ($action === NULL) {
    $action = 'reset';
} else {
    $action = strtolower($action);
}

switch ($action) {
    case 'reset':
        //Reset values for variables
        $learner_id = '';
        $first_name = '';
        $last_name = '';
        $contact = '';
        $grade = '';
        $parent_id = '';
        $bus_no = '';
        $bus_route = '';
        $pick_id = '';
        $pick_number = '';
        $pick_name = '';
        $pick_time = '';
        $drop_name = '';
        $drop_time = '';

        //Load view
        include 'application_form.php';
        break;

    case 'apply':
        // Copy form values to local variables
        $learner_id = filter_input(INPUT_POST, 'learnerid');
        $first_name = filter_input(INPUT_POST, 'learnerfname');
        $last_name = filter_input(INPUT_POST, 'learnerlname');
        $contact = filter_input(INPUT_POST, 'learnercontact');
        $grade = filter_input(INPUT_POST, 'grade');
        $parent_id = filter_input(INPUT_POST, 'parentid');
        $bus_no = filter_input(INPUT_POST, 'busno');
        $bus_route = filter_input(INPUT_POST, 'busroute');
        $pick_id = filter_input(INPUT_POST, 'pickid');
        $pick_number = filter_input(INPUT_POST, 'picknumber');
        $pick_name = filter_input(INPUT_POST, 'pickname');
        $pick_time = filter_input(INPUT_POST, 'picktime');
        $drop_name = filter_input(INPUT_POST, 'dropname');
        $drop_time = filter_input(INPUT_POST, 'droptime');
        $admin_id = filter_input(INPUT_POST, 'adminid');

        //Check limits
        $bus1_count = get_busCount();
        if ($bus1_count >= 35) {

            //Add learner to wait list
            $waiting_list = add_waitList($learner_id);
            if ($waiting_list) {
                $app = add_application($learner_id, $admin_id, $bus_no, $pick_id);
                if ($app) {

                    // Set up email variables
                    $to_address = '43205364@mylife.unisa.ac.za';
                    $to_name = 'Monwabisi Nazo';
                    $from_address = 'monwa.nazo@gmail.com';
                    $from_name = 'Monwabisi Nazo';
                    $subject = 'Application Received';
                    $body = '<p>Thank you for your application for space in the bus transaport.</p>' .
                            '<p>Sorry but the bus is currently full, you have been put on waiting list</p>' .
                            '<p>We will let you know once space becomes availabe.</p>' .
                            '<p>Regards,</p>' .
                            '<p>Impumemelo High School</p>';
                    $is_body_html = true;

                    // Send email
                    try {
                        send_email(
                                $to_address,
                                $to_name,
                                $from_address,
                                $from_name,
                                $subject,
                                $body,
                                $is_body_html
                        );
                        echo 'Application sent successfully!';
                        include '../parent/parent_page.php';
                    } catch (Exception $ex) {
                        $error = $ex->getMessage();
                        echo 'Application not submitted';
                        include 'application_form.php';
                    }
                }
            }
        } else {
            //Add learner to a bus
            add_application($learner_id, $admin_id, $bus_no, $pick_id);
            update_learner($learner_id, $bus_no, $pick_id);

            // Set up email variables
            $to_address = '43205364@mylife.unisa.ac.za';
            $to_name = 'Monwabisi Nazo';
            $from_address = 'monwa.nazo@gmail.com';
            $from_name = 'Monwabisi Nazo';
            $subject = 'Application Received';
            $body = '<p>Thank you for your application for space in the bus transaport.</p>' .
                    '<p>Your application has been processed successfully!</p>' .
                    '<p>We will provide further details once all applications are finalized.</p>' .
                    '<p>Regards,</p>' .
                    '<p>Impumemelo High School</p>';
            $is_body_html = true;

            // Send email
            try {
                send_email(
                        $to_address,
                        $to_name,
                        $from_address,
                        $from_name,
                        $subject,
                        $body,
                        $is_body_html
                );
                echo 'Application sent successfully!';
                include '../parent/parent_page.php';
            } catch (Exception $ex) {
                $error = $ex->getMessage();
                echo 'Application not submitted';
                include 'application_form.php';
            }
        }
        break;
}


