<?php
include '../view/header.php';
require_once '../model/brt_database.php';

//Connection to DB
$con = mysqli_connect("localhost", "root", "", "bus_registration_system");

//Get parents id's
$query1 = mysqli_query($con, "select * from parent");

//Get learner id's
$query2 = mysqli_query($con, "select * from learner");

//Get bus route number
$query3 = mysqli_query($con, "select * from bus");

//Get pick number
$query4 = mysqli_query($con, "select * from route");

//Get admin id
$query5 = mysqli_query($con, "select AdminId from administrator");
?>

<br>
<div class="container">
    <div class="form">
        <form action="." method="post" id="form-register">
            <input type="hidden" name="action" value="apply">
            <h3 class="h3 mb-3 font-weight-normal">Bus Application Form</h3><br>
            <div class="col-lg-6 ">
                <label for="learnerid">LearnerId</label>
                <select name="learnerid" id="learnerid" class="form-control" onChange="fetchLearner(this.value);">
                    <option value="">Select Learner Id</option>
                    <?php
                    while ($r = mysqli_fetch_assoc($query2)) {
                        $k = $r['LearnerId'];
                        echo '<option value="' . $k . '">' . $k . '</option>';
                    }
                    ?>
                </select>
                <br>
                <div id="learnerDetails">
                    <label for="firstname">Learner First Name</label>
                    <input type="text" name="learnerfname" id="learnerfname" class="form-control"
                        placeholder="First Name" value="" required>
                    <br>
                    <label for="lastname">Learner Last Name</label>
                    <input type="text" name="learnerlname" id="learnerlname" class="form-control"
                        placeholder="Last Name" value="" required>
                    <br>
                    <label for="contact">Learner Contact</label>
                    <input type="text" name="learnercontact" id="learnercontact" class="form-control"
                        placeholder="Contact" value="" required><br>
                    <label for="grade">Grade</label>
                    <input type="text" name="grade" id="grade" class="form-control" placeholder="Grade  " value=""
                        required><br>
                    <label for="parent">ParentId</label>
                    <input type="text" name="parentid" id="parentid" class="form-control" placeholder="Parent Id"
                        value="" required><br>
                </div>
                <label for="busnumber">Bus Number</label>
                <select name="busno" id="busno" class="form-control" onChange="fetchBus(this.value);">
                    <option value="">Select Bus No</option>
                    <?php
                    while ($r = mysqli_fetch_assoc($query3)) {
                        $j = $r['BusNo'];
                        echo '<option value="' . $j . '">' . $j . '</option>';
                    }
                    ?>
                </select><br>
                <div id="busDetails">
                    <label for="bus_route">Bus Route Name</label>
                    <input type="text" name="busroute" id="busroute" class="form-control" placeholder="Bus Route Name"
                        value="" required><br>
                </div>
            </div>
            <div class="col-lg-6 ">
                <label for="pick_id">Pick Id</label>
                <select name="pickid" id="pickid" class="form-control" onChange="fetchPick(this.value)">
                    <option value="">Select Pick Id</option>
                    <?php
                    while ($r = mysqli_fetch_assoc($query4)) {
                        $l = $r['PickId'];
                        echo '<option value="' . $l . '">' . $l . '</option>';
                    }
                    ?>
                </select><br>
                <div id="pickDetails">
                    <label for="pick_number">Pick Number</label>
                    <input type="text" name="picknumber" id="picknumber" class="form-control" placeholder="Pick Number"
                        value="" required><br>
                    <label for="pick_name">Pick Name</label>
                    <input type="text" name="pickname" id="pickname" class="form-control" placeholder="Pick Name"
                        value="" required><br>
                    <label for="pick_time">Pick Time</label>
                    <input type="text" name="picktime" id="picktime" class="form-control" placeholder="Pick Time"
                        value="" required><br>
                    <label for="drop_number">Drop Number</label>
                    <input type="text" name="dropnumber" id="dropnumber" class="form-control" placeholder="Pick Number"
                        value="" required><br>
                    <label for="drop_name">Drop Name</label>
                    <input type="text" name="dropname" id="dropname" class="form-control" placeholder="Pick Name"
                        value="" required><br>
                    <label for="drop_time">Drop Time</label>
                    <input type="text" name="droptime" id="droptime" class="form-control" placeholder="Pick Time"
                        value="" required><br>
                </div>
                <div id="adminDetails">
                    <label for="admin_id">Admin Id</label>
                    <select name="adminid" id="adminid" class="form-control" onChange="fetchAdmin(this.value);">
                        <option value="">Select AdminId</option>
                        <?php
                        while ($r = mysqli_fetch_assoc($query5)) {
                            $m = $r['AdminId'];
                            echo '<option value="' . $m . '">' . $m . '</option>';
                        }
                        ?>
                    </select><br>
                    <br>
                </div>
            </div>
            <div>
                <button class="btn btn-lg btn-primary btn-block" type="submit" name="action"
                    value="apply">Submit</button><br>
                <button class="btn btn-lg btn-primary btn-block" type="submit" name="action"
                    value="reset">Reset</button>
            </div>
        </form>
    </div>
</div>
</br></br>
</body>
<?php
include '../view/footer.php';

