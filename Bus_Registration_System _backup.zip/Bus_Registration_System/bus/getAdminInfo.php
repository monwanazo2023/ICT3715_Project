<?php

require_once '../model/brt_database.php';

//Get bus information

$con = mysqli_connect("localhost", "root", "", "bus_registration_system");
$m = $_POST["adminid"];
$query = "select AdminId from administrator where AdminId = {$m}";
$result = mysqli_query($con, $query);
$rows = mysqli_fetch_array($result);
if ($rows == true) {
    print ' <label for="admin_id">Admin Id</label>
            <input type="text" name="adminid" id="adminid" class="form-control" placeholder="Admin Id" 
                      value="' . $rows["AdminId"] . '" required>'
            .'<br>'
            . '';
}   
