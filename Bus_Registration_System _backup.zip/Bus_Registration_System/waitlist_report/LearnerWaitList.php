<?php

// Require autoload.php from koolreport library
require_once "../koolreport/core/autoload.php";

//Specify some data processes that will be used to process
use \koolreport\KoolReport;
use \koolreport\processes\Group;
use \koolreport\processes\Sort;
use \koolreport\processes\Limit;
use \koolreport\processes\TimeBucket;

//Define the class
class LearnerWaitList extends \koolreport\KoolReport
{

    use \koolreport\clients\Bootstrap;

    protected function settings()
    {

        //Connection to DB for data
        return array(
            "dataSources" => array(
                "waiting" => array(
                    'connectionString' => 'mysql:host=localhost;dbname=bus_registration_system',
                    'username' => 'root',
                    'password' => '',
                    'charset' => 'utf8'
                ),
            )
        );
    }

    public function setup()
    {

        //Select the data source then pipe data through various process
        $this->src("waiting")
            ->query("SELECT `learner`.`FirstName`, `learner`.`LastName`,`learner`.`Contact`,`learner`.`Grade`,
                    `waitlist`.`WaitId`,`waitlist`.`WaitDate`FROM `learner` 
	INNER JOIN `waitlist` ON `waitlist`.`LearnerId` = `learner`.`LearnerId` GROUP BY `waitlist`.`LearnerId`;")
            ->pipe($this->dataStore('learners_wait_list'));
    }
}
