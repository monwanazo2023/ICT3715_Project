<?php 
//require_once '../vendor/autoload.php';
include '../view/header.php';

require_once "LearnerWaitList.php";
$report = new LearnerWaitList;
$report->run()->render();

include '../view/footer.php';