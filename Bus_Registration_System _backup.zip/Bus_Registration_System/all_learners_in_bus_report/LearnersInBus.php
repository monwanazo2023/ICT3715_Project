<?php

require_once "../koolreport/core/autoload.php";

use \koolreport\processes\Group;
use \koolreport\processes\Sort;
use \koolreport\processes\Limit;

class LearnersInBus extends \koolreport\KoolReport {

    use \koolreport\clients\Bootstrap;

    protected function settings() {
        return array(
            "dataSources" => array(
                "learners" => array(
                    'connectionString' => 'mysql:host=localhost;dbname=bus_registration_system',
                    'username' => 'root',
                    'password' => '',
                    'charset' => 'utf8'
                ),
            )
        );
    }

    public function setup() {
        $this->src("learners")
                ->query("SELECT `bus`.`BusRouteNo`,`learner`.`FirstName`,`learner`.`LastName`,`learner`.`Contact`,
    `learner`.`Grade`,`route`.`PickId`,`route`.`BusNo`,`route`.`PickName`,`route`.`PickTime`,`route`.`DropName`,`route`.`DropTime`
    FROM `bus` INNER JOIN `learner` ON `bus`.`BusNo` = `learner`.`BusNo`
 INNER JOIN `route` ON `learner`.`LearnerId` = `route`.`PickId`")
                ->SaveTo($root)
                ->pipe($this->dataStore('learners_in_bus'));

//        $root->pipe(new Group(array(
//                            "by" => "BusNo",
//                            "count" => "LearnerId"
//                        )
//        )
//        )
//                ->pipe(new Limit(array(10)))
//                ->pipe($this->dataStore('learners_by_bus'));
    }
}
